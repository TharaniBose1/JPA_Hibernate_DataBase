package com.cg.payroll.client;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.InvalidEmailException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException, InterruptedException {
		PayrollServices payrollServices=new PayrollServicesImpl();
	try {
	 int Id=	payrollServices.acceptAssociateDetails(72000, "Tharani", "Bose", "CSE", "Software Engineer", "GD733YD", "tharanibose1@gmail.com", new Salary(8000, 1500, 1300), new BankDetails(1212457456, "ICICI", "icici456GT"));
		System.out.println("Generated Id"+Id);
		Associate ass=payrollServices.getAssociateDetails(1);
		System.out.println("Generated details "+ass.getFirstName());
		int salary=payrollServices.calculateNetSalary(Id);
		System.out.println("Salary obtained is"+salary);
		int Id2=	payrollServices.acceptAssociateDetails(12000, "Rani", "P", "CSE", "Software Engineer", "GD733YD", "tharanibose1@gmail.com", new Salary(8000, 1500, 1300), new BankDetails(1212457456, "ICICI", "icici456GT"));
		System.out.println("Generated Id"+Id2);
		System.out.println(payrollServices.getAssociateDetails(Id).getFirstName());
	//	System.out.println(payrollServices.getAssociateDetails(3).getLastName());
		System.out.println(payrollServices.deleteAssociate(2));
	//	System.out.println(payrollServices.deleteAssociate(Id));
	} catch (InvalidEmailException e) {
		e.printStackTrace();
	}
	}}





