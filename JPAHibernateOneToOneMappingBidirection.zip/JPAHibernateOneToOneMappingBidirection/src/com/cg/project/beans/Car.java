package com.cg.project.beans;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
@Entity
public class Car {
	@Id
	@GeneratedValue(strategy= GenerationType.TABLE)
private int carCode;
private String carName;
private long price;
//@OneToOne
 @ManyToOne
Customer customer;
public Car() {}
public int getCarCode() {
	return carCode;
}
public void setCarCode(int carCode) {
	this.carCode = carCode;
}
public String getCarName() {
	return carName;
}
public void setCarName(String carName) {
	this.carName = carName;
}
public long getPrice() {
	return price;
}
public void setPrice(long price) {
	this.price = price;
}


}
