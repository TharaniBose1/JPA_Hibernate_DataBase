package com.cg.project.beans;
import java.util.List;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
@Entity
public class Employee {
	private String firstName,lastName;
	@ElementCollection(fetch=FetchType.EAGER)
	@JoinTable(name="Address")
private List<Address>addresses;
@Id
@GeneratedValue(strategy=GenerationType.TABLE)
	private int employeeId;
	public Employee() {}
	public Employee(String firstName, String lastName, List<Address> addresses) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.addresses = addresses;
	}
	public Employee(String firstName, String lastName, List<Address> addresses, int employeeId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.addresses = addresses;
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<Address> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	

}
