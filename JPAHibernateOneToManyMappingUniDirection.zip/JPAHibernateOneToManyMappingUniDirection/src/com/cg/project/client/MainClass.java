package com.cg.project.client;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.project.beans.Employee;
public class MainClass {
	public static void main(String[] args) {
		
EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");		
/*EntityManager entityManager=entityManagerFactory.createEntityManager();
entityManager.persist(employee);*/
	}

}
