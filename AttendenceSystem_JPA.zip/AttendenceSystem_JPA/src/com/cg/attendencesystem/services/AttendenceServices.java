package com.cg.attendencesystem.services;
import java.util.List;

import com.cg.attendencesystem.beans.*;
import com.cg.attendencesystem.exceptions.StudentDetailsNotFoundException;
public interface AttendenceServices {
int acceptStudentDetails(String firstName, String lastName, CourseDetails courseDetails,
		ExamFeeDetails examFeeDetails, LectureDetails lectureDetails);//constor should b called
int calculatePenality(int studentId)throws StudentDetailsNotFoundException;
Student getStudentDetails(int studentId)throws StudentDetailsNotFoundException;
List <Student>getAllStudentDetails();
}
