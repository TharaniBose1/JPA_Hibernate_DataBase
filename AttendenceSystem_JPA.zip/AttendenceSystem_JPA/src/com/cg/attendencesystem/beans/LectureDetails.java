package com.cg.attendencesystem.beans;
import javax.persistence.Embeddable;
@Embeddable
public class LectureDetails {
private int noOfLecturesConducted,noOfLecturesAttended,noOfSubjects;
private float attendencePercentage;
public LectureDetails() {}
public LectureDetails(int noOfLecturesConducted, int noOfLecturesAttended) {
	super();
	this.noOfLecturesConducted = noOfLecturesConducted;
	this.noOfLecturesAttended = noOfLecturesAttended;
}
public int getNoOfLecturesConducted() {
	return noOfLecturesConducted;
}
public void setNoOfLecturesConducted(int noOfLecturesConducted) {
	this.noOfLecturesConducted = noOfLecturesConducted;
}
public int getNoOfLecturesAttended() {
	return noOfLecturesAttended;
}
public void setNoOfLecturesAttended(int noOfLecturesAttended) {
	this.noOfLecturesAttended = noOfLecturesAttended;
}
public int getNoOfSubjects() {
	return noOfSubjects;
}
public void setNoOfSubjects(int noOfSubjects) {
	this.noOfSubjects = noOfSubjects;
}
public float getAttendencePercentage() {
	return attendencePercentage;
}
public void setAttendencePercentage(float attendencePercentage) {
	this.attendencePercentage = attendencePercentage;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + Float.floatToIntBits(attendencePercentage);
	result = prime * result + noOfLecturesAttended;
	result = prime * result + noOfLecturesConducted;
	result = prime * result + noOfSubjects;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	LectureDetails other = (LectureDetails) obj;
	if (Float.floatToIntBits(attendencePercentage) != Float.floatToIntBits(other.attendencePercentage))
		return false;
	if (noOfLecturesAttended != other.noOfLecturesAttended)
		return false;
	if (noOfLecturesConducted != other.noOfLecturesConducted)
		return false;
	if (noOfSubjects != other.noOfSubjects)
		return false;
	return true;
}


}

