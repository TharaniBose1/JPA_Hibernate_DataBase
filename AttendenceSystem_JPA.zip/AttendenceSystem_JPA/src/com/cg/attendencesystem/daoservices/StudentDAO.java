package com.cg.attendencesystem.daoservices;
import java.util.List;
import com.cg.attendencesystem.beans.*;
public interface StudentDAO {
Student save(Student student);
boolean update(Student student);
Student  findId(int studentId);
List <Student>  findAllId();
}
