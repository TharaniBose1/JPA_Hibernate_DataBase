package com.cg.attendencesystem.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.attendencesystem.beans.Student;
public class StudentDAOImpl implements StudentDAO {
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Student save(Student student) {
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	entityManager.getTransaction().begin();
	entityManager.persist(student);
	entityManager.getTransaction().commit();
		return student;
	}
	@Override
	public boolean update(Student student) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(student);
		entityManager.getTransaction().commit();
		return true;
	}
	@Override
	public Student findId(int studentId) {
		return entityManagerFactory.createEntityManager().find(Student.class, studentId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Student> findAllId() {
		
		return entityManagerFactory.createEntityManager().createQuery("from Student refObj").getResultList();
	}


}
//if(student.getLectureDetails().getAttendencePercentage()<60 && student.getLectureDetails().getAttendencePercentage()>=50)